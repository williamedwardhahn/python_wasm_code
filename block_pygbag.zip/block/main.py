import pygame, sys
from pygame.math import Vector2

pygame.init()

# Initialize colors
GREEN = (173, 204, 96)
DARK_GREEN = (43, 51, 24)

# Initialize dimensions
cell_size = 30
number_of_cells = 25
OFFSET = 75

class Block:
    def __init__(self):
        self.position = Vector2(6, 9)
        self.direction = Vector2(1, 0)

    def draw(self):
        block_rect = pygame.Rect(OFFSET + self.position.x * cell_size, OFFSET + self.position.y * cell_size, cell_size, cell_size)
        pygame.draw.rect(screen, DARK_GREEN, block_rect)

    def update(self):
        self.position += self.direction
        self.position.x = self.position.x % number_of_cells
        self.position.y = self.position.y % number_of_cells

# Initialize screen
screen = pygame.display.set_mode((2 * OFFSET + cell_size * number_of_cells, 2 * OFFSET + cell_size * number_of_cells))
pygame.display.set_caption("Controlled Block")
clock = pygame.time.Clock()

# Initialize block
block = Block()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                block.direction = Vector2(0, -1)
            if event.key == pygame.K_DOWN:
                block.direction = Vector2(0, 1)
            if event.key == pygame.K_LEFT:
                block.direction = Vector2(-1, 0)
            if event.key == pygame.K_RIGHT:
                block.direction = Vector2(1, 0)

    # Update the block's position
    block.update()

    # Drawing
    screen.fill(GREEN)
    block.draw()

    pygame.display.update()
    clock.tick(10)

